-- Add popular_medical_beauty section to page_sections table
INSERT INTO page_sections (section_name, position, article_id) VALUES
  -- Popular Medical Beauty section (3 articles)
  ('popular_medical_beauty', 1, NULL),
  ('popular_medical_beauty', 2, NULL),
  ('popular_medical_beauty', 3, NULL);