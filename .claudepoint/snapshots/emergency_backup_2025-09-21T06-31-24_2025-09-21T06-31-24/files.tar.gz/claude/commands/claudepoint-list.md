---
description: Browse your claudepoint vault // Digital artifact collection
---

🗂️ Use the ClaudePoint MCP tool list_claudepoints to browse your vault.

Display the results with hacker style showing:
- Claudepoint name
- Description
- Date created
- Number of files
- Size
