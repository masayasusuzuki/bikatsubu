---
description: View your coding adventure timeline // Development history
---

📡 Use the ClaudePoint MCP tool get_changelog to view your development timeline.

Display the timeline with:
- Action types (CREATE_CLAUDEPOINT, RESTORE, etc.)
- Timestamps
- Descriptions and details
- Recent activity focus

This shows your complete coding journey across all sessions.
