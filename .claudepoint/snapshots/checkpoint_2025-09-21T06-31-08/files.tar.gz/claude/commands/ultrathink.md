---
description: Activate ultrathink mode // Deep analysis and reasoning
---

🧠 Execute ultrathink prompt for enhanced reasoning and analysis.

This command simply runs the "ultrathink" prompt to activate Claude's deep thinking mode.

Steps:
1. Execute the prompt: ultrathink
2. Let Claude engage in enhanced reasoning and analysis

Perfect for complex problems that need deeper thought.
