---
description: Instant time hack // Quick restore to your last claudepoint
---

🔄 Instant time travel back to your last claudepoint! Use the ClaudePoint MCP tool for quick restoration.

Steps:
1. Use the undo_claudepoint tool from ClaudePoint
2. This will automatically restore your last claudepoint
3. Celebrate the successful time hack with a cool message!

Perfect for when you need to quickly undo recent changes and get back to a stable state.
